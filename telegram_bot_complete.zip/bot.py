from telegram import Update, ChatPermissions
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
import random
from config import BOT_TOKEN

POETRY = [
    "तुम्हारी एक मुस्कान, मेरी पूरी कायनात है ❤️",
    "इश्क़ वो नहीं जो दुनिया को दिखाया जाए, इश्क़ वो है जो दिल में निभाया जाए",
    "Love is not about possession, it is about appreciation"
]

GAMES = [
    "🎲 Dice Game: Roll /dice",
    "🏀 Basketball: /basketball",
    "🎯 Dart: /dart",
    "🎳 Bowling: /bowling"
]

STUDY_MATERIAL = {
    "python": "https://docs.python.org/3/tutorial/",
    "jee": "https://jeemain.nta.nic.in/",
    "neet": "https://neet.nta.nic.in/",
    "english": "https://www.grammarly.com/blog/"
}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🤖 Welcome to All-in-One Telegram Bot")

async def games(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(random.choice(GAMES))

async def poetry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(random.choice(POETRY))

async def study(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Use /study python|jee|neet|english")
        return
    subject = context.args[0].lower()
    await update.message.reply_text(STUDY_MATERIAL.get(subject, "Not found"))

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("games", games))
    app.add_handler(CommandHandler("poetry", poetry))
    app.add_handler(CommandHandler("study", study))
    app.run_polling()

if __name__ == "__main__":
    main()
